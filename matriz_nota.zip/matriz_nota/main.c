#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

   int main()
{
    setlocale(LC_ALL,"");
    int linha, col;
    float mat_notas[16][2];

     system("color 79");

    for(linha=0; linha<16;linha++)
     {

      for(col=0;col<2;col++)
            {
            printf("\nINFORME A NOTA DA %d PROVA: ",col+1);
            scanf ("%f", &mat_notas[linha][col]);
            }

        system("cls");
     }
           printf( "\n AS NOTAS DA PRIMEIRA E SEGUNDA PROVA MAIORES OU IGUAL A SEIS SAO: \n ");
           printf(" p1 \t  p2 \n");
             for(linha=0; linha<16;linha++)
             {

                 for(col=0;col<2;col++)
                 {
                     if(mat_notas[linha][col]>=6)
                       {
                        printf( " %.2f \t",mat_notas[linha][col]);

                       }
                 }printf("\n");


              }

             printf( "\n AS NOTAS DA SEGUNDA PROVA MENORES QUE SEIS SAO: ");
             for(linha=0; linha<16;linha++)
             {
                 if(mat_notas[linha][1]<6)
                   {
                    printf( "\n %.2f ",mat_notas[linha][1]);

                   }
             }
            printf("\n");

        return 0;

    }

